const books = [
 {id:1,title:"Higher Engineering Mathematics",author:"B. S. Grewal",edition:"44th Edition",isbn:"9788174091955",branch:"Engineering",retail:1450,rent:380,used:780,condition:"Like New",color:"#24456b",tag:"BESTSELLER",buyback:.55},
 {id:2,title:"Operating System Concepts",author:"Abraham Silberschatz",edition:"10th Edition",isbn:"9781119800361",branch:"Computer Science",retail:1450,rent:380,used:820,condition:"Good with Notes",color:"#315c65",tag:"POPULAR",buyback:.55,notes:true},
 {id:3,title:"Core Java Volume I",author:"Cay S. Horstmann",edition:"12th Edition",isbn:"9780137673629",branch:"Computer Science",retail:899,rent:250,used:520,condition:"Like New",color:"#bd754f",buyback:.5},
 {id:4,title:"Data Structures & Algorithms",author:"Mark Allen Weiss",edition:"4th Edition",isbn:"9780132847377",branch:"Computer Science",retail:1199,rent:320,used:650,condition:"Good with Notes",color:"#4d5984",notes:true,buyback:.5},
 {id:5,title:"Computer Networks",author:"Andrew S. Tanenbaum",edition:"5th Edition",isbn:"9780132126953",branch:"Computer Science",retail:1099,rent:300,used:590,condition:"Acceptable",color:"#8b684d",buyback:.45},
 {id:6,title:"Engineering Physics",author:"Gaur & Gupta",edition:"Latest Edition",isbn:"9788121928504",branch:"Engineering",retail:650,rent:180,used:350,condition:"Like New",color:"#547b83",buyback:.5},
 {id:7,title:"Engineering Chemistry",author:"Jain & Jain",edition:"17th Edition",isbn:"9788121903594",branch:"Engineering",retail:720,rent:190,used:390,condition:"Good with Notes",color:"#826b91",notes:true,buyback:.45},
 {id:8,title:"Programming in ANSI C",author:"E. Balagurusamy",edition:"8th Edition",isbn:"978935316 પર".replace(" પર",""),branch:"Computer Science",retail:599,rent:160,used:310,condition:"Like New",color:"#3f756b",buyback:.5},
 {id:9,title:"Database System Concepts",author:"Silberschatz, Korth & Sudarshan",edition:"7th Edition",isbn:"9780078022159",branch:"Computer Science",retail:1299,rent:340,used:690,condition:"Brand New",color:"#b06d56",buyback:.55},
 {id:10,title:"Software Engineering",author:"Ian Sommerville",edition:"10th Edition",isbn:"9780133943030",branch:"Computer Science",retail:999,rent:270,used:540,condition:"Good with Notes",color:"#475c78",notes:true,buyback:.5},
 {id:11,title:"Discrete Mathematics",author:"Kenneth H. Rosen",edition:"8th Edition",isbn:"9780073383095",branch:"Science",retail:1190,rent:310,used:610,condition:"Like New",color:"#97764c",buyback:.5},
 {id:12,title:"Introduction to Algorithms",author:"Cormen, Leiserson et al.",edition:"4th Edition",isbn:"9780262046305",branch:"Computer Science",retail:1899,rent:490,used:1050,condition:"Acceptable",color:"#405a72",buyback:.45},
 {id:13,title:"Digital Design",author:"M. Morris Mano",edition:"6th Edition",isbn:"9780134549897",branch:"Engineering",retail:999,rent:270,used:520,condition:"Like New",color:"#9b654e",buyback:.5},
 {id:14,title:"Signals and Systems",author:"Alan V. Oppenheim",edition:"2nd Edition",isbn:"9780138147570",branch:"Engineering",retail:1350,rent:350,used:700,condition:"Good with Notes",color:"#526c82",notes:true,buyback:.5},
 {id:15,title:"Fundamentals of Electric Circuits",author:"Charles K. Alexander",edition:"7th Edition",isbn:"9781260226409",branch:"Engineering",retail:1450,rent:380,used:760,condition:"Like New",color:"#607b65",buyback:.55},
 {id:16,title:"Anatomy & Physiology",author:"Elaine N. Marieb",edition:"11th Edition",isbn:"9780134580999",branch:"Medical",retail:1699,rent:440,used:900,condition:"Good with Notes",color:"#8d626d",notes:true,buyback:.5},
 {id:17,title:"Guyton and Hall Textbook of Medical Physiology",author:"John E. Hall",edition:"14th Edition",isbn:"9780323597128",branch:"Medical",retail:1999,rent:520,used:1100,condition:"Like New",color:"#536d82",buyback:.55},
 {id:18,title:"Robbins Basic Pathology",author:"Vinay Kumar",edition:"10th Edition",isbn:"9780323353175",branch:"Medical",retail:1799,rent:470,used:950,condition:"Acceptable",color:"#9a704f",buyback:.45},
 {id:19,title:"Organic Chemistry",author:"Paula Yurkanis Bruice",edition:"8th Edition",isbn:"9780134042282",branch:"Science",retail:1499,rent:390,used:790,condition:"Like New",color:"#667b68",buyback:.5},
 {id:20,title:"University Physics",author:"Hugh D. Young",edition:"15th Edition",isbn:"9780135159552",branch:"Science",retail:1599,rent:420,used:850,condition:"Good with Notes",color:"#7c668d",notes:true,buyback:.5},
 {id:21,title:"Principles of Economics",author:"N. Gregory Mankiw",edition:"9th Edition",isbn:"9780357038314",branch:"Commerce",retail:1199,rent:310,used:620,condition:"Like New",color:"#4b7180",buyback:.5},
 {id:22,title:"Financial Accounting",author:"Jerry J. Weygandt",edition:"4th Edition",isbn:"978111959459 is".replace(" is",""),branch:"Commerce",retail:999,rent:260,used:510,condition:"Good with Notes",color:"#9c7355",notes:true,buyback:.5},
 {id:23,title:"Business Statistics",author:"S. P. Gupta",edition:"Latest Edition",isbn:"978817  ".trim()+"409",branch:"Commerce",retail:699,rent:180,used:360,condition:"Acceptable",color:"#557b69",buyback:.45},
 {id:24,title:"Engineering Mathematics II",author:"B. V. Ramana",edition:"Latest Edition",isbn:"9780070682580",branch:"Engineering",retail:899,rent:230,used:470,condition:"Brand New",color:"#6b6287",buyback:.55},
 {id:25,title:"Artificial Intelligence: A Modern Approach",author:"Stuart Russell & Peter Norvig",edition:"4th Edition",isbn:"9780134610993",branch:"Computer Science",retail:1799,rent:470,used:940,condition:"Like New",color:"#385e67",buyback:.55}
];

const $ = s => document.querySelector(s);
const money = n => "₹" + Math.round(n).toLocaleString("en-IN");
const readStore = (key, fallback=[]) => { try{return JSON.parse(localStorage.getItem(key))||fallback}catch{return fallback} };
let cart = readStore("bb_cart",[]);
let rentals = readStore("bb_rentals",[]);
let listings = readStore("bb_listings",[]);
let selectedCategory = "all";
let activeBook = null;
let purchaseMode = "rent";
let duration = 120;

function save(){localStorage.setItem("bb_cart",JSON.stringify(cart));localStorage.setItem("bb_rentals",JSON.stringify(rentals));localStorage.setItem("bb_listings",JSON.stringify(listings));}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),2500)}
function coverMarkup(book,extra=""){return `<div class="cover ${extra}" style="background:${book.color}"><span class="cover-title">${book.title.split(" ").slice(0,4).join("<br>")}</span><span class="cover-author">${book.author}</span><span class="cover-publisher">BOOKBAZAAR LIBRARY</span></div>`}
function renderBooks(){
 const q=$("#searchInput").value.toLowerCase().trim(), branch=$("#branchFilter").value, condition=$("#conditionFilter").value;
 const filtered=books.filter(b=>(selectedCategory==="all"||b.branch===selectedCategory)&&(branch==="all"||b.branch===branch)&&(condition==="all"||b.condition===condition)&&[b.title,b.author,b.isbn,b.branch].join(" ").toLowerCase().includes(q));
 $("#resultCount").textContent=`${filtered.length} BOOK${filtered.length===1?"":"S"}`;
 $("#bookGrid").innerHTML=filtered.map(b=>`<article class="book-card" data-id="${b.id}" tabindex="0" role="button" aria-label="View ${b.title} details"><div class="cover-wrap"><span class="condition-tag">${b.condition}</span>${b.notes?'<span class="annotation-tag">✎ NOTES</span>':""}${coverMarkup(b)}</div><div class="book-info"><span class="book-branch">${b.branch}</span><h3>${b.title}</h3><p class="book-author">${b.author} · ${b.edition}</p><div class="book-meta"><span class="book-price">${money(b.rent)} <small>/ rent</small></span><span class="view-details">VIEW DETAILS ↗</span></div></div></article>`).join("");
 $("#emptyState").classList.toggle("hidden",filtered.length!==0);
 $("#bookGrid").classList.toggle("hidden",filtered.length===0);
}
function openBook(id){
 activeBook=books.find(b=>b.id===Number(id));if(!activeBook)return;
 purchaseMode="rent";duration=120;renderBookModal();
 $("#bookModal").classList.remove("hidden");
}
function renderBookModal(){
 const b=activeBook;
 $("#modalContent").innerHTML=`<div class="modal-book-head"><div class="modal-book-cover" style="background:${b.color}">${b.title.split(" ").slice(0,5).join("<br>")}</div><div><span class="book-branch">${b.branch}</span><h2 id="modalTitle">${b.title}</h2><p>${b.author}<br>${b.edition}<br>ISBN: ${b.isbn}</p><span class="edition-badge">✓ Edition details displayed</span></div></div>
 <div class="purchase-tabs"><button data-mode="rent" class="active">Rent for semester</button><button data-mode="used">Buy secondhand</button><button data-mode="new">Buy new</button></div>
 <div id="purchaseDetails"></div>`;
 $("#modalContent").querySelectorAll("[data-mode]").forEach(btn=>btn.addEventListener("click",()=>{purchaseMode=btn.dataset.mode;$("#modalContent").querySelectorAll("[data-mode]").forEach(x=>x.classList.toggle("active",x===btn));renderPurchaseDetails()}));
 renderPurchaseDetails();
}
function renderPurchaseDetails(){
 const b=activeBook, target=$("#purchaseDetails");
 if(purchaseMode==="rent"){
  const rentPrice=Math.round(b.rent*(duration/120)),deposit=Math.round(rentPrice*.5),refund=Math.round(deposit*.8);
  target.innerHTML=`<div class="calculator"><div class="calculator-top"><span>Choose rental duration</span><strong>${duration} days</strong></div><input id="durationSlider" type="range" min="30" max="120" step="30" value="${duration}"><div class="duration-labels"><span>30 days</span><span>60 days</span><span>90 days</span><span>120 days</span></div><div class="calc-results"><div><span>Rental fee</span><strong>${money(rentPrice)}</strong></div><div><span>Deposit · 50%</span><strong>${money(deposit)}</strong></div><div><span>Pay today</span><strong>${money(rentPrice+deposit)}</strong></div></div><div class="saving-note">You save ${money(Math.max(0,b.retail-rentPrice))} (${Math.round((1-rentPrice/b.retail)*100)}%) vs buying new. Estimated deposit refund: ${money(refund)} on verified good return.</div></div><div class="modal-actions"><button class="primary-button" id="addToCart">Add rental to cart ↗</button><button class="secondary-button" id="rentNow">Rent now</button></div><p class="cart-note">Demo calculation: deposit is 50% of the rental fee. 80% of the deposit is shown as refundable after a verified good-condition return, as outlined in the brief.</p>`;
  $("#durationSlider").addEventListener("input",e=>{duration=Number(e.target.value);renderPurchaseDetails()});
  $("#addToCart").addEventListener("click",()=>addCart(b,"rent",rentPrice,deposit,duration));
  $("#rentNow").addEventListener("click",()=>checkoutRental(b,rentPrice,deposit,duration));
 }else{
  const price=purchaseMode==="used"?b.used:b.retail, buyback=purchaseMode==="used"?Math.round(price*b.buyback):Math.round(price*.35);
  target.innerHTML=`<div class="calculator"><div class="calc-results"><div><span>${purchaseMode==="used"?"Secondhand price":"Retail price"}</span><strong>${money(price)}</strong></div><div><span>Estimated buyback</span><strong>${money(buyback)}</strong></div><div><span>Net cost*</span><strong>${money(price-buyback)}</strong></div></div><div class="buyback-box"><span>Estimated future buyback in good condition</span><strong>${money(buyback)}</strong></div><p class="cart-note">*Illustrative estimate only. Final buyback depends on book condition and verification. ${purchaseMode==="used"?"":"New-book estimate uses a 35% illustrative return value."}</p></div><div class="modal-actions"><button class="primary-button" id="buyAdd">Add to cart ↗</button><button class="secondary-button" id="buyNow">Buy now</button></div>`;
  $("#buyAdd").addEventListener("click",()=>addCart(b,purchaseMode,price,0,0));$("#buyNow").addEventListener("click",()=>{cart=[{bookId:b.id,mode:purchaseMode,price,deposit:0,duration:0}];save();checkoutCart()});
 }
}
function addCart(book,mode,price,deposit,days){cart.push({bookId:book.id,mode,price,deposit,duration:days});save();updateCartCount();toast("Added to your cart");$("#bookModal").classList.add("hidden")}
function updateCartCount(){$("#cartCount").textContent=cart.length}
function openCart(){$("#cartModal").classList.remove("hidden");renderCart()}
function renderCart(){
 const el=$("#cartContent");
 if(!cart.length){el.innerHTML='<p class="cart-note">Your cart is empty. Find a book to get started.</p><a class="text-link" href="#catalog">Explore books →</a>';return}
 const total=cart.reduce((s,x)=>s+x.price+x.deposit,0);
 el.innerHTML=cart.map((x,i)=>{const b=books.find(y=>y.id===x.bookId);return `<div class="cart-line"><span>${b?.title||"Student listing"}<br><small>${x.mode==="rent"?`Rent · ${x.duration} days · deposit ${money(x.deposit)}`:x.mode==="used"?"Secondhand":"New"}</small></span><strong>${money(x.price+x.deposit)}</strong><button class="remove-cart" data-i="${i}" aria-label="Remove item">×</button></div>`}).join("")+`<div class="cart-total"><span>Total due</span><strong>${money(total)}</strong></div><button class="primary-button full-button" id="checkoutBtn">Continue to demo checkout ↗</button><p class="cart-note">This frontend demo does not process real payments or orders.</p>`;
 el.querySelectorAll(".remove-cart").forEach(btn=>btn.addEventListener("click",()=>{cart.splice(Number(btn.dataset.i),1);save();updateCartCount();renderCart()}));
 $("#checkoutBtn").addEventListener("click",checkoutCart);
}
function checkoutCart(){if(!cart.length)return;const rentalsToAdd=cart.filter(x=>x.mode==="rent");rentalsToAdd.forEach(x=>{rentals.push({...x,start:Date.now(),due:Date.now()+x.duration*86400000,deposit:x.deposit})});cart=[];save();updateCartCount();$("#cartModal").classList.add("hidden");renderRentals();toast("Demo checkout complete — rental added!");}
function checkoutRental(book,price,deposit,days){rentals.push({bookId:book.id,mode:"rent",price,deposit,duration:days,start:Date.now(),due:Date.now()+days*86400000});save();renderRentals();$("#bookModal").classList.add("hidden");toast("Rental added to your dashboard");}
function renderRentals(){
 $("#rentalCount").textContent=`${rentals.length} ACTIVE RENTAL${rentals.length===1?"":"S"}`;
 if(!rentals.length){$("#rentalList").innerHTML='<div class="dashboard-empty"><span>▤</span><h3>Your rentals will appear here</h3><p>Choose a book and rent it to start your dashboard.</p><a href="#catalog" class="text-link">Browse books →</a></div>';return}
 $("#rentalList").innerHTML=rentals.map((r,i)=>{const b=books.find(x=>x.id===r.bookId)||{title:"Student listed book",color:"#536c7d"};const days=Math.ceil((r.due-Date.now())/86400000);return `<article class="rental-row"><div class="mini-cover" style="background:${b.color}">${b.title.split(" ").slice(0,3).join(" ")}</div><div><h3>${b.title}</h3><p>${r.duration} day rental · Paid ${money(r.price+r.deposit)}</p></div><div class="rental-due"><strong class="${days<=7?"return-warning":""}">${days>0?days+" days left":"Return due"}</strong><span>Due ${new Date(r.due).toLocaleDateString("en-IN")}${days<=7&&days>0?" · Reminder window":""}</span></div><button class="secondary-button mark-return" data-i="${i}">Mark returned</button></article>`}).join("");
 $("#rentalList").querySelectorAll(".mark-return").forEach(btn=>btn.addEventListener("click",()=>{const r=rentals[Number(btn.dataset.i)];rentals.splice(Number(btn.dataset.i),1);save();renderRentals();toast(`Return marked in demo. Estimated refund: ${money(r.deposit*.8)}`)}));
}
function isbnValid(raw){const s=raw.replace(/[^0-9Xx]/g,"").toUpperCase();if(s.length===10){let sum=0;for(let i=0;i<10;i++){const n=s[i]==="X"?10:Number(s[i]);if(!Number.isInteger(n)||(!/\d/.test(s[i])&&s[i]!=="X")||(s[i]==="X"&&i!==9))return false;sum+=n*(10-i)}return sum%11===0}if(s.length===13&&/^\d{13}$/.test(s)){let sum=0;for(let i=0;i<12;i++)sum+=Number(s[i])*(i%2?3:1);return (10-sum%10)%10===Number(s[12])}return false}
$("#sellIsbn").addEventListener("input",e=>{const valid=isbnValid(e.target.value),filled=e.target.value.length>0;$("#isbnFeedback").textContent=valid?"✓ ISBN checksum looks valid.":filled?"ISBN format or checksum is not valid yet.":"Enter a valid 10 or 13 digit ISBN." ;$("#isbnFeedback").className="isbn-feedback "+(valid?"valid":filled?"invalid":"")});
$("#sellForm").addEventListener("submit",e=>{e.preventDefault();const isbn=$("#sellIsbn").value;if(!isbnValid(isbn)){toast("Please enter a valid ISBN-10 or ISBN-13");return}const item={id:Date.now(),isbn,title:$("#sellTitle").value,condition:$("#sellCondition").value,price:Number($("#sellPrice").value),notes:$("#sellNotes").value};listings.push(item);save();e.target.reset();$("#isbnFeedback").textContent="Enter a valid 10 or 13 digit ISBN.";toast("Listing saved in this browser demo");});
$("#bookGrid").addEventListener("click",e=>{const card=e.target.closest(".book-card");if(card)openBook(card.dataset.id)});
$("#bookGrid").addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.classList.contains("book-card")){e.preventDefault();openBook(e.target.dataset.id)}});
$("#searchInput").addEventListener("input",renderBooks);$("#branchFilter").addEventListener("change",()=>{selectedCategory="all";document.querySelectorAll(".chip").forEach(c=>c.classList.toggle("active",c.dataset.category==="all"));renderBooks()});$("#conditionFilter").addEventListener("change",renderBooks);
document.querySelectorAll(".chip").forEach(c=>c.addEventListener("click",()=>{selectedCategory=c.dataset.category;$("#branchFilter").value="all";document.querySelectorAll(".chip").forEach(x=>x.classList.toggle("active",x===c));renderBooks()}));
$("#resetFilters").addEventListener("click",()=>{$("#searchInput").value="";$("#branchFilter").value="all";$("#conditionFilter").value="all";selectedCategory="all";document.querySelectorAll(".chip").forEach(c=>c.classList.toggle("active",c.dataset.category==="all"));renderBooks()});
$("#cartBtn").addEventListener("click",openCart);$("#dashboardBtn").addEventListener("click",()=>$("#dashboard").scrollIntoView({behavior:"smooth"}));
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>b.closest(".modal-backdrop").classList.add("hidden")));
document.querySelectorAll(".modal-backdrop").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.classList.add("hidden")}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".modal-backdrop").forEach(m=>m.classList.add("hidden"));if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("#searchInput").focus()}});
renderBooks();renderRentals();updateCartCount();
