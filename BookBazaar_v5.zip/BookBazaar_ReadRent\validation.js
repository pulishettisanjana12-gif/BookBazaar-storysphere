// validation.js — All input validation logic, decoupled from DOM
// Addresses: "Security & Robustness" feedback + edge case handling

/**
 * Validates ISBN-10 and ISBN-13 via checksum.
 * @param {string} raw
 * @returns {{ valid: boolean, message: string }}
 */
export function validateISBN(raw) {
  const s = raw.replace(/[^0-9Xx]/g, "").toUpperCase();

  if (!s) return { valid: false, message: "Enter a valid 10 or 13 digit ISBN." };

  if (s.length === 10) {
    let sum = 0;
    for (let i = 0; i < 10; i++) {
      const ch = s[i];
      if (ch === "X" && i !== 9) return { valid: false, message: "X is only valid as the last digit of an ISBN-10." };
      const n = ch === "X" ? 10 : Number(ch);
      if (isNaN(n)) return { valid: false, message: "ISBN contains an invalid character." };
      sum += n * (10 - i);
    }
    return sum % 11 === 0
      ? { valid: true, message: "✓ ISBN-10 checksum is valid." }
      : { valid: false, message: "ISBN-10 checksum is not valid. Double-check the number." };
  }

  if (s.length === 13) {
    if (!/^\d{13}$/.test(s)) return { valid: false, message: "ISBN-13 must be 13 digits with no letters." };
    let sum = 0;
    for (let i = 0; i < 12; i++) sum += Number(s[i]) * (i % 2 ? 3 : 1);
    const check = (10 - sum % 10) % 10;
    return check === Number(s[12])
      ? { valid: true, message: "✓ ISBN-13 checksum is valid." }
      : { valid: false, message: "ISBN-13 checksum is not valid. Double-check the number." };
  }

  return { valid: false, message: `ISBN must be 10 or 13 digits (you entered ${s.length}).` };
}

/**
 * Validates the sell-a-book form fields.
 * Returns { valid: boolean, errors: { field: message } }
 */
export function validateListingForm({ isbn, title, price, condition }) {
  const errors = {};

  const isbnResult = validateISBN(isbn || "");
  if (!isbnResult.valid) errors.isbn = isbnResult.message;

  if (!title || title.trim().length < 3) {
    errors.title = "Book title must be at least 3 characters.";
  } else if (title.trim().length > 200) {
    errors.title = "Title is too long (max 200 characters).";
  }

  const priceNum = Number(price);
  if (!price && price !== 0) {
    errors.price = "Please enter a price.";
  } else if (!Number.isFinite(priceNum) || priceNum <= 0) {
    errors.price = "Price must be a positive number (e.g. 350).";
  } else if (priceNum > 10000) {
    errors.price = "Price seems too high. Max is ₹10,000.";
  } else if (!Number.isInteger(priceNum)) {
    errors.price = "Price must be a whole number (no decimals).";
  }

  const validConditions = ["Like New", "Brand New", "Good with Notes", "Acceptable"];
  if (!validConditions.includes(condition)) {
    errors.condition = "Please select a valid condition.";
  }

  return { valid: Object.keys(errors).length === 0, errors };
}

/**
 * Validates the rental duration slider value.
 * @param {number} days
 * @returns {{ valid: boolean, message: string }}
 */
export function validateDuration(days) {
  const allowed = [30, 60, 90, 120];
  if (!allowed.includes(Number(days))) {
    return { valid: false, message: "Duration must be 30, 60, 90 or 120 days." };
  }
  return { valid: true, message: "" };
}
