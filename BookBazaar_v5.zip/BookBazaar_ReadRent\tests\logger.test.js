// tests/logger.test.js
// Unit tests for the structured logging utility

import { jest } from "@jest/globals";

// Mock sessionStorage
const sess = {};
global.sessionStorage = {
  getItem:    key => sess[key] ?? null,
  setItem:    (key, val) => { sess[key] = val; },
  removeItem: key => { delete sess[key]; },
};

import { createLogger, getLogs, clearLogs } from "../logger.js";

beforeEach(() => { clearLogs(); jest.spyOn(console, "info").mockImplementation(() => {}); });
afterEach(() => jest.restoreAllMocks());

describe("createLogger", () => {
  test("returns an object with debug/info/warn/error", () => {
    const log = createLogger("test");
    expect(typeof log.debug).toBe("function");
    expect(typeof log.info).toBe("function");
    expect(typeof log.warn).toBe("function");
    expect(typeof log.error).toBe("function");
  });

  test("info log is persisted with correct fields", () => {
    const log = createLogger("mymodule");
    log.info("something happened", "detail");
    const entries = getLogs();
    expect(entries.length).toBe(1);
    expect(entries[0].level).toBe("INFO");
    expect(entries[0].context).toBe("mymodule");
    expect(entries[0].message).toBe("something happened");
    expect(entries[0].detail).toBe("detail");
    expect(entries[0].ts).toBeTruthy();
  });

  test("multiple levels all saved", () => {
    const log = createLogger("multi");
    log.debug("d"); log.info("i"); log.warn("w"); log.error("e");
    const levels = getLogs().map(e => e.level);
    expect(levels).toContain("DEBUG");
    expect(levels).toContain("INFO");
    expect(levels).toContain("WARN");
    expect(levels).toContain("ERROR");
  });

  test("log without detail has no detail field (or undefined)", () => {
    const log = createLogger("nodetail");
    log.info("bare message");
    const entry = getLogs()[0];
    expect(entry.message).toBe("bare message");
    expect(entry.detail).toBeUndefined();
  });
});

describe("getLogs", () => {
  test("returns newest first", () => {
    const log = createLogger("order");
    log.info("first"); log.info("second"); log.info("third");
    const entries = getLogs();
    expect(entries[0].message).toBe("third");
    expect(entries[2].message).toBe("first");
  });
  test("returns empty array when no logs", () => {
    expect(getLogs()).toEqual([]);
  });
});

describe("clearLogs", () => {
  test("removes all entries", () => {
    createLogger("c").info("x");
    clearLogs();
    expect(getLogs()).toEqual([]);
  });
});
