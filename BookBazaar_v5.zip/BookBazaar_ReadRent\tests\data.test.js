// tests/data.test.js
// Unit tests for the data layer (filtering, storage helpers)

import { books, filterBooks, findBook } from "../data.js";

describe("filterBooks", () => {
  test("no filters returns all 25 books", () => {
    expect(filterBooks({}).length).toBe(25);
  });

  test("branch filter narrows results", () => {
    const cs = filterBooks({ branch: "Computer Science" });
    expect(cs.every(b => b.branch === "Computer Science")).toBe(true);
    expect(cs.length).toBeGreaterThan(0);
  });

  test("category filter works same as branch", () => {
    const a = filterBooks({ branch: "Medical" });
    const b = filterBooks({ category: "Medical" });
    expect(a.length).toBe(b.length);
  });

  test("condition filter narrows results", () => {
    const brandNew = filterBooks({ condition: "Brand New" });
    expect(brandNew.every(b => b.condition === "Brand New")).toBe(true);
  });

  test("query matches title case-insensitively", () => {
    const r = filterBooks({ query: "cormen" });
    expect(r.length).toBeGreaterThan(0);
    expect(r[0].title).toMatch(/Algorithms/i);
  });

  test("query matches ISBN", () => {
    const r = filterBooks({ query: "9780262046305" });
    expect(r.length).toBe(1);
    expect(r[0].isbn).toBe("9780262046305");
  });

  test("query with no match returns empty", () => {
    expect(filterBooks({ query: "zzzzzzzzz" }).length).toBe(0);
  });

  test("combined branch + query narrows correctly", () => {
    const r = filterBooks({ branch: "Medical", query: "physiology" });
    expect(r.every(b => b.branch === "Medical")).toBe(true);
    expect(r.length).toBeGreaterThan(0);
  });

  test("1000-book performance: filter runs under 50ms", () => {
    // Stress test with a large simulated dataset (addresses scalability feedback)
    const big = Array.from({ length: 1000 }, (_, i) => ({
      id: i + 100,
      title: `Book ${i}`,
      author: `Author ${i}`,
      isbn: "9780262046305",
      branch: i % 2 === 0 ? "Engineering" : "Computer Science",
      condition: "Like New",
    }));

    const startTime = performance.now();
    const result = big.filter(b =>
      b.branch === "Engineering" &&
      [b.title, b.author, b.isbn, b.branch].join(" ").toLowerCase().includes("book 5")
    );
    const elapsed = performance.now() - startTime;

    expect(elapsed).toBeLessThan(50);
    expect(result.length).toBeGreaterThan(0);
  });
});

describe("findBook", () => {
  test("returns book by numeric id", () => {
    expect(findBook(1).title).toBe("Higher Engineering Mathematics");
  });
  test("returns book by string id", () => {
    expect(findBook("12").title).toMatch(/Algorithms/);
  });
  test("returns null for unknown id", () => {
    expect(findBook(999)).toBeNull();
  });
  test("all 25 books have unique ids", () => {
    const ids = books.map(b => b.id);
    expect(new Set(ids).size).toBe(25);
  });
  test("all books have required fields", () => {
    books.forEach(b => {
      expect(b.id).toBeDefined();
      expect(b.title).toBeTruthy();
      expect(b.isbn).toBeTruthy();
      expect(b.rent).toBeGreaterThan(0);
      expect(b.retail).toBeGreaterThan(0);
    });
  });
});
