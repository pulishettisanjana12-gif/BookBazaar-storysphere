// store.js — Observer-pattern state store
// Addresses: "Explore the use of the Observer pattern for state management"
// A minimal reactive store: modules subscribe to named slices;
// any write notifies all listeners for that slice.

import { readStore, writeStore } from "./data.js";
import { createLogger } from "./logger.js";

const log = createLogger("store");

/**
 * @typedef {{ [slice: string]: any }} State
 * @typedef {(newValue: any, oldValue: any) => void} Listener
 */

/** Internal state map and subscriber registry */
const _state   = {};
const _subs    = {}; // slice -> Set<Listener>

/**
 * Initialises a slice with a value loaded from localStorage (or a fallback).
 * @param {string} key        Slice name, doubles as the localStorage key.
 * @param {any}    fallback   Value to use when nothing is persisted.
 */
export function initSlice(key, fallback) {
  _state[key]  = readStore(key, fallback);
  _subs[key]   = new Set();
  log.debug("initSlice", key);
}

/**
 * Reads the current value of a slice.
 * @param {string} key
 */
export function getSlice(key) {
  return _state[key];
}

/**
 * Writes a new value to a slice, persists it, and notifies subscribers.
 * @param {string} key
 * @param {any}    value
 */
export function setSlice(key, value) {
  const old = _state[key];
  _state[key] = value;
  writeStore(key, value);
  if (_subs[key]) {
    _subs[key].forEach(fn => {
      try { fn(value, old); }
      catch (e) { log.error(`subscriber error on slice "${key}"`, e.message); }
    });
  }
  log.debug(`setSlice "${key}"`, Array.isArray(value) ? `length=${value.length}` : typeof value);
}

/**
 * Subscribes a listener to changes on a slice.
 * Returns an unsubscribe function.
 * @param {string}   key
 * @param {Listener} fn
 * @returns {() => void}
 */
export function subscribe(key, fn) {
  if (!_subs[key]) _subs[key] = new Set();
  _subs[key].add(fn);
  log.debug(`subscribe to "${key}"`, `total=${_subs[key].size}`);
  return () => {
    _subs[key].delete(fn);
    log.debug(`unsubscribe from "${key}"`);
  };
}

/**
 * Convenience: update a slice by passing a function that receives the current value.
 * @param {string}             key
 * @param {(current: any) => any} updater
 */
export function updateSlice(key, updater) {
  setSlice(key, updater(getSlice(key)));
}
