// app.js — View layer: DOM interactions only
// Data logic lives in data.js; validation logic lives in validation.js
// Refactored per evaluation feedback: separate Data layer from View layer

import { books, readStore, saveAll, findBook, filterBooks } from "./data.js";
import { validateISBN, validateListingForm, validateDuration } from "./validation.js";

// ─── State ────────────────────────────────────────────────────────────────────
let cart = readStore("bb_cart", []);
let rentals = readStore("bb_rentals", []);
let listings = readStore("bb_listings", []);
let selectedCategory = "all";
let activeBook = null;
let purchaseMode = "rent";
let duration = 120;

// Pagination state
const PAGE_SIZE = 8;
let currentPage = 1;
let filteredBooks = [...books];

// ─── Utilities ────────────────────────────────────────────────────────────────
const $ = s => document.querySelector(s);
const money = n => "₹" + Math.round(n).toLocaleString("en-IN");

function save() { saveAll(cart, rentals, listings); }

function toast(msg, type = "info") {
  const el = $("#toast");
  el.textContent = msg;
  el.className = `toast show toast--${type}`;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => el.classList.remove("show"), 2800);
}

function coverMarkup(book, extra = "") {
  return `<div class="cover ${extra}" style="background:${book.color}">
    <span class="cover-title">${book.title.split(" ").slice(0, 4).join("<br>")}</span>
    <span class="cover-author">${book.author}</span>
    <span class="cover-publisher">BOOKBAZAAR LIBRARY</span>
  </div>`;
}

function showFieldError(fieldId, message) {
  const el = document.getElementById(fieldId);
  if (!el) return;
  el.classList.add("field-error");
  let hint = el.nextElementSibling;
  if (!hint || !hint.classList.contains("field-hint")) {
    hint = document.createElement("span");
    hint.className = "field-hint error-hint";
    el.parentNode.insertBefore(hint, el.nextSibling);
  }
  hint.textContent = message;
  hint.style.color = "#c45f50";
}

function clearFieldError(fieldId) {
  const el = document.getElementById(fieldId);
  if (!el) return;
  el.classList.remove("field-error");
  const hint = el.nextElementSibling;
  if (hint && hint.classList.contains("error-hint")) hint.remove();
}

// ─── Catalogue / Pagination ──────────────────────────────────────────────────
function getFilters() {
  return {
    query: $("#searchInput").value,
    branch: $("#branchFilter").value,
    condition: $("#conditionFilter").value,
    category: selectedCategory,
  };
}

function renderBooks() {
  filteredBooks = filterBooks(getFilters());
  currentPage = 1;
  renderPage();
}

function renderPage() {
  const total = filteredBooks.length;
  const start = (currentPage - 1) * PAGE_SIZE;
  const slice = filteredBooks.slice(start, start + PAGE_SIZE);

  $("#resultCount").textContent = `${total} BOOK${total === 1 ? "" : "S"}`;

  $("#bookGrid").innerHTML = slice.map(b => `
    <article class="book-card" data-id="${b.id}" tabindex="0" role="button" aria-label="View ${b.title} details">
      <div class="cover-wrap">
        <span class="condition-tag">${b.condition}</span>
        ${b.notes ? '<span class="annotation-tag">✎ NOTES</span>' : ""}
        ${b.tag ? `<span class="book-tag">${b.tag}</span>` : ""}
        ${coverMarkup(b)}
      </div>
      <div class="book-info">
        <span class="book-branch">${b.branch}</span>
        <h3>${b.title}</h3>
        <p class="book-author">${b.author} · ${b.edition}</p>
        <div class="book-meta">
          <span class="book-price">${money(b.rent)} <small>/ rent</small></span>
          <span class="view-details">VIEW DETAILS ↗</span>
        </div>
      </div>
    </article>`).join("");

  $("#emptyState").classList.toggle("hidden", total !== 0);
  $("#bookGrid").classList.toggle("hidden", total === 0);
  renderPagination(total);
}

function renderPagination(total) {
  let el = $("#pagination");
  if (!el) {
    el = document.createElement("div");
    el.id = "pagination";
    el.className = "pagination";
    $("#bookGrid").insertAdjacentElement("afterend", el);
  }
  const totalPages = Math.ceil(total / PAGE_SIZE);
  if (totalPages <= 1) { el.innerHTML = ""; return; }

  el.innerHTML = `
    <button class="page-btn" ${currentPage === 1 ? "disabled" : ""} data-page="${currentPage - 1}">← Prev</button>
    <span class="page-info">Page ${currentPage} of ${totalPages}</span>
    <button class="page-btn" ${currentPage === totalPages ? "disabled" : ""} data-page="${currentPage + 1}">Next →</button>`;

  el.querySelectorAll(".page-btn:not([disabled])").forEach(btn =>
    btn.addEventListener("click", () => {
      currentPage = Number(btn.dataset.page);
      renderPage();
      $("#catalog").scrollIntoView({ behavior: "smooth" });
    })
  );
}

// ─── Book Modal ───────────────────────────────────────────────────────────────
function openBook(id) {
  try {
    activeBook = findBook(id);
    if (!activeBook) throw new Error(`Book id ${id} not found`);
    purchaseMode = "rent";
    duration = 120;
    renderBookModal();
    $("#bookModal").classList.remove("hidden");
  } catch (e) {
    console.error("openBook error:", e);
    toast("Could not open book details. Please try again.", "error");
  }
}

function renderBookModal() {
  const b = activeBook;
  $("#modalContent").innerHTML = `
    <div class="modal-book-head">
      <div class="modal-book-cover" style="background:${b.color}">${b.title.split(" ").slice(0, 5).join("<br>")}</div>
      <div>
        <span class="book-branch">${b.branch}</span>
        <h2 id="modalTitle">${b.title}</h2>
        <p>${b.author}<br>${b.edition}<br>ISBN: ${b.isbn}</p>
        <span class="edition-badge">✓ Edition details displayed</span>
      </div>
    </div>
    <div class="purchase-tabs">
      <button data-mode="rent" class="active">Rent for semester</button>
      <button data-mode="used">Buy secondhand</button>
      <button data-mode="new">Buy new</button>
    </div>
    <div id="purchaseDetails"></div>`;

  $("#modalContent").querySelectorAll("[data-mode]").forEach(btn =>
    btn.addEventListener("click", () => {
      purchaseMode = btn.dataset.mode;
      $("#modalContent").querySelectorAll("[data-mode]").forEach(x => x.classList.toggle("active", x === btn));
      renderPurchaseDetails();
    })
  );
  renderPurchaseDetails();
}

function renderPurchaseDetails() {
  const b = activeBook;
  const target = $("#purchaseDetails");
  if (!target) return;

  if (purchaseMode === "rent") {
    const rentPrice = Math.round(b.rent * (duration / 120));
    const deposit = Math.round(rentPrice * 0.5);
    const refund = Math.round(deposit * 0.8);
    target.innerHTML = `
      <div class="calculator">
        <div class="calculator-top"><span>Choose rental duration</span><strong>${duration} days</strong></div>
        <input id="durationSlider" type="range" min="30" max="120" step="30" value="${duration}" aria-label="Rental duration in days">
        <div class="duration-labels"><span>30 days</span><span>60 days</span><span>90 days</span><span>120 days</span></div>
        <div class="calc-results">
          <div><span>Rental fee</span><strong>${money(rentPrice)}</strong></div>
          <div><span>Deposit · 50%</span><strong>${money(deposit)}</strong></div>
          <div><span>Pay today</span><strong>${money(rentPrice + deposit)}</strong></div>
        </div>
        <div class="saving-note">You save ${money(Math.max(0, b.retail - rentPrice))} (${Math.round((1 - rentPrice / b.retail) * 100)}%) vs buying new. Estimated deposit refund: ${money(refund)} on verified good return.</div>
      </div>
      <div class="modal-actions">
        <button class="primary-button" id="addToCart">Add rental to cart ↗</button>
        <button class="secondary-button" id="rentNow">Rent now</button>
      </div>
      <p class="cart-note">Deposit is 50% of the rental fee. 80% is refundable after a verified good-condition return.</p>`;

    $("#durationSlider").addEventListener("input", e => {
      const val = Number(e.target.value);
      const { valid, message } = validateDuration(val);
      if (!valid) { toast(message, "error"); return; }
      duration = val;
      renderPurchaseDetails();
    });
    $("#addToCart").addEventListener("click", () => addCart(b, "rent", rentPrice, deposit, duration));
    $("#rentNow").addEventListener("click", () => checkoutRental(b, rentPrice, deposit, duration));
  } else {
    const price = purchaseMode === "used" ? b.used : b.retail;
    const buyback = purchaseMode === "used" ? Math.round(price * b.buyback) : Math.round(price * 0.35);
    target.innerHTML = `
      <div class="calculator">
        <div class="calc-results">
          <div><span>${purchaseMode === "used" ? "Secondhand price" : "Retail price"}</span><strong>${money(price)}</strong></div>
          <div><span>Estimated buyback</span><strong>${money(buyback)}</strong></div>
          <div><span>Net cost*</span><strong>${money(price - buyback)}</strong></div>
        </div>
        <div class="buyback-box">
          <span>Estimated future buyback in good condition</span>
          <strong>${money(buyback)}</strong>
        </div>
        <p class="cart-note">*Illustrative estimate only. Final buyback depends on book condition and verification. ${purchaseMode === "used" ? "" : "New-book estimate uses a 35% illustrative return value."}</p>
      </div>
      <div class="modal-actions">
        <button class="primary-button" id="buyAdd">Add to cart ↗</button>
        <button class="secondary-button" id="buyNow">Buy now</button>
      </div>`;
    $("#buyAdd").addEventListener("click", () => addCart(b, purchaseMode, price, 0, 0));
    $("#buyNow").addEventListener("click", () => {
      cart = [{ bookId: b.id, mode: purchaseMode, price, deposit: 0, duration: 0 }];
      save();
      checkoutCart();
    });
  }
}

// ─── Cart ─────────────────────────────────────────────────────────────────────
function addCart(book, mode, price, deposit, days) {
  cart.push({ bookId: book.id, mode, price, deposit, duration: days });
  save();
  updateCartCount();
  toast("Added to your cart");
  $("#bookModal").classList.add("hidden");
}

function updateCartCount() { $("#cartCount").textContent = cart.length; }

function openCart() { $("#cartModal").classList.remove("hidden"); renderCart(); }

function renderCart() {
  const el = $("#cartContent");
  if (!el) return;
  if (!cart.length) {
    el.innerHTML = '<p class="cart-note">Your cart is empty. Find a book to get started.</p><a class="text-link" href="#catalog">Explore books →</a>';
    return;
  }
  const total = cart.reduce((s, x) => s + x.price + x.deposit, 0);
  el.innerHTML = cart.map((x, i) => {
    const b = findBook(x.bookId);
    return `<div class="cart-line">
      <span>${b?.title || "Student listing"}<br>
      <small>${x.mode === "rent" ? `Rent · ${x.duration} days · deposit ${money(x.deposit)}` : x.mode === "used" ? "Secondhand" : "New"}</small></span>
      <strong>${money(x.price + x.deposit)}</strong>
      <button class="remove-cart" data-i="${i}" aria-label="Remove item">×</button>
    </div>`;
  }).join("") +
    `<div class="cart-total"><span>Total due</span><strong>${money(total)}</strong></div>
     <button class="primary-button full-button" id="checkoutBtn">Continue to demo checkout ↗</button>
     <p class="cart-note">This frontend demo does not process real payments or orders.</p>`;

  el.querySelectorAll(".remove-cart").forEach(btn =>
    btn.addEventListener("click", () => {
      cart.splice(Number(btn.dataset.i), 1);
      save();
      updateCartCount();
      renderCart();
    })
  );
  try {
    $("#checkoutBtn").addEventListener("click", checkoutCart);
  } catch (e) {
    console.error("Checkout button bind error:", e);
  }
}

function checkoutCart() {
  if (!cart.length) return;
  cart.filter(x => x.mode === "rent").forEach(x => {
    rentals.push({ ...x, start: Date.now(), due: Date.now() + x.duration * 86400000 });
  });
  cart = [];
  save();
  updateCartCount();
  $("#cartModal").classList.add("hidden");
  renderRentals();
  toast("Demo checkout complete — rental added!");
}

function checkoutRental(book, price, deposit, days) {
  rentals.push({ bookId: book.id, mode: "rent", price, deposit, duration: days, start: Date.now(), due: Date.now() + days * 86400000 });
  save();
  renderRentals();
  $("#bookModal").classList.add("hidden");
  toast("Rental added to your dashboard");
}

// ─── Rentals Dashboard ────────────────────────────────────────────────────────
function renderRentals() {
  const count = rentals.length;
  $("#rentalCount").textContent = `${count} ACTIVE RENTAL${count === 1 ? "" : "S"}`;

  if (!count) {
    $("#rentalList").innerHTML = `
      <div class="dashboard-empty">
        <span>▤</span>
        <h3>Your rentals will appear here</h3>
        <p>Choose a book and rent it to start your dashboard.</p>
        <a href="#catalog" class="text-link">Browse books →</a>
      </div>`;
    return;
  }

  $("#rentalList").innerHTML = rentals.map((r, i) => {
    const b = findBook(r.bookId) || { title: "Student listed book", color: "#536c7d" };
    const days = Math.ceil((r.due - Date.now()) / 86400000);
    const isOverdue = days <= 0;
    const isWarning = days > 0 && days <= 7;
    return `<article class="rental-row">
      <div class="mini-cover" style="background:${b.color}">${b.title.split(" ").slice(0, 3).join(" ")}</div>
      <div>
        <h3>${b.title}</h3>
        <p>${r.duration} day rental · Paid ${money(r.price + r.deposit)}</p>
      </div>
      <div class="rental-due">
        <strong class="${isOverdue ? "return-warning" : isWarning ? "return-warning" : ""}">
          ${isOverdue ? "OVERDUE" : days + " days left"}
        </strong>
        <span>Due ${new Date(r.due).toLocaleDateString("en-IN")}${isWarning && !isOverdue ? " · Return soon" : ""}</span>
      </div>
      <button class="secondary-button mark-return" data-i="${i}">Mark returned</button>
    </article>`;
  }).join("");

  $("#rentalList").querySelectorAll(".mark-return").forEach(btn =>
    btn.addEventListener("click", () => {
      try {
        const r = rentals[Number(btn.dataset.i)];
        rentals.splice(Number(btn.dataset.i), 1);
        save();
        renderRentals();
        toast(`Return marked. Estimated refund: ${money(r.deposit * 0.8)}`);
      } catch (e) {
        console.error("Mark return error:", e);
        toast("Could not mark return. Please refresh.", "error");
      }
    })
  );
}

// ─── Sell Form ────────────────────────────────────────────────────────────────
$("#sellIsbn").addEventListener("input", e => {
  const { valid, message } = validateISBN(e.target.value);
  const filled = e.target.value.length > 0;
  const fb = $("#isbnFeedback");
  fb.textContent = message;
  fb.className = "isbn-feedback " + (valid ? "valid" : filled ? "invalid" : "");
});

$("#sellForm").addEventListener("submit", e => {
  e.preventDefault();

  // Clear previous errors
  ["sellIsbn", "sellTitle", "sellPrice"].forEach(clearFieldError);

  const isbn = $("#sellIsbn").value;
  const title = $("#sellTitle").value;
  const price = $("#sellPrice").value;
  const condition = $("#sellCondition").value;
  const notes = $("#sellNotes").value.trim();

  const { valid, errors } = validateListingForm({ isbn, title, price, condition });

  if (!valid) {
    if (errors.isbn) showFieldError("sellIsbn", errors.isbn);
    if (errors.title) showFieldError("sellTitle", errors.title);
    if (errors.price) showFieldError("sellPrice", errors.price);
    toast("Please fix the errors above before submitting.", "error");
    return;
  }

  const item = {
    id: Date.now(),
    isbn: isbn.replace(/[^0-9Xx]/g, ""),
    title: title.trim(),
    condition,
    price: Number(price),
    notes,
  };

  listings.push(item);
  save();
  e.target.reset();
  $("#isbnFeedback").textContent = "Enter a valid 10 or 13 digit ISBN.";
  $("#isbnFeedback").className = "isbn-feedback";
  toast("Listing saved in this browser demo");
});

// ─── Event Wiring ─────────────────────────────────────────────────────────────
try {
  $("#bookGrid").addEventListener("click", e => {
    const card = e.target.closest(".book-card");
    if (card) openBook(card.dataset.id);
  });

  $("#bookGrid").addEventListener("keydown", e => {
    if ((e.key === "Enter" || e.key === " ") && e.target.classList.contains("book-card")) {
      e.preventDefault();
      openBook(e.target.dataset.id);
    }
  });
} catch (e) {
  console.error("BookGrid event binding error:", e);
}

$("#searchInput").addEventListener("input", renderBooks);
$("#branchFilter").addEventListener("change", () => {
  selectedCategory = "all";
  document.querySelectorAll(".chip").forEach(c => c.classList.toggle("active", c.dataset.category === "all"));
  renderBooks();
});
$("#conditionFilter").addEventListener("change", renderBooks);

document.querySelectorAll(".chip").forEach(c => c.addEventListener("click", () => {
  selectedCategory = c.dataset.category;
  $("#branchFilter").value = "all";
  document.querySelectorAll(".chip").forEach(x => x.classList.toggle("active", x === c));
  renderBooks();
}));

try {
  $("#resetFilters").addEventListener("click", () => {
    $("#searchInput").value = "";
    $("#branchFilter").value = "all";
    $("#conditionFilter").value = "all";
    selectedCategory = "all";
    document.querySelectorAll(".chip").forEach(c => c.classList.toggle("active", c.dataset.category === "all"));
    renderBooks();
  });
} catch (e) {
  console.error("Reset filters binding error:", e);
}

$("#cartBtn").addEventListener("click", openCart);
$("#dashboardBtn").addEventListener("click", () => $("#dashboard").scrollIntoView({ behavior: "smooth" }));

document.querySelectorAll("[data-close]").forEach(b => b.addEventListener("click", () => b.closest(".modal-backdrop").classList.add("hidden")));
document.querySelectorAll(".modal-backdrop").forEach(m => m.addEventListener("click", e => { if (e.target === m) m.classList.add("hidden"); }));

document.addEventListener("keydown", e => {
  if (e.key === "Escape") document.querySelectorAll(".modal-backdrop").forEach(m => m.classList.add("hidden"));
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); $("#searchInput").focus(); }
});

// ─── Init ─────────────────────────────────────────────────────────────────────
renderBooks();
renderRentals();
updateCartCount();
